<?php

return [
    'subjects' => [
        'email_confirmation' => 'Confirm your {{SITE_NAME}} account',
        'share' => "{{DISPLAY_NAME}} shared '{{ITEM_NAME}}' with you",
        'generic' => '{{EMAIL_SUBJECT}}',
    ]
];