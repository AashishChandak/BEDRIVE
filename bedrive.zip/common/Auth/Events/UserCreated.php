<?php

namespace Common\Auth\Events;

use Common\Auth\User;

class UserCreated
{
    /**
     * @var User
     */
    public $user;

    /**
     * @param User $user
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }
}