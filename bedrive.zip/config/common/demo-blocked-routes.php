<?php

return [
    //sitemap
    ['method' => 'POST', 'name' => 'admin/sitemap/generate']
];